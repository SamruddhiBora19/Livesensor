# livesensor
i want to create sendor fault prediction project 
